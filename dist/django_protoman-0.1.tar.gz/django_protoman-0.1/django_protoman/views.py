from django.views.generic.base import TemplateView

"""
Prototyper views. Keep track of which views you'll need to deal with moving forward.
"""

class Awesomesauce(TemplateView):
    template_name='prototyper/awesomesauce.html'


class Awesomesauce(TemplateView):
    template_name='prototyper/awesomesauce.html'


class Awesomesauce(TemplateView):
    template_name='prototyper/awesomesauce.html'

